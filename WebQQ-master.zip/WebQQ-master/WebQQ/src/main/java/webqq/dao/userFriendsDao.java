package webqq.dao;

public interface userFriendsDao
{

}
