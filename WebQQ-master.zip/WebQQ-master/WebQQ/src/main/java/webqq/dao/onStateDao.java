package webqq.dao;

public interface onStateDao
{

}
