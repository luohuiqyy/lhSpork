package webqq.dao;

public interface chatInfoDao
{

}
