package webqq.dao;

public interface userSessionDao
{

}
